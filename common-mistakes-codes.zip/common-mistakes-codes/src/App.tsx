import Parent from "./100-tips-and-tricks/9";

export default function App() {
  return (
    <>
      <Parent />
    </>
  );
}
